# Helper function for the GestioIP discovery scripts

package Gipfuncs;

use strict;
use Net::SMTP;
use POSIX qw(strftime);
use Time::Local;

sub send_mail {
	my %args = @_;

    my $debug=$args{debug} || 0;
    my $mail_from=$args{mail_from};
	#"user\@domain.net";
    my $mail_to=$args{mail_to} || "";
	# mail_to array_ref;
    my $subject=$args{'subject'} || "";
    my $server=$args{'smtp_server'} || "";
    my $message=$args{'smtp_message'} || "";
    my $log=$args{'log'} || "";
    my $gip_job_status_id=$args{'gip_job_status_id'} || "";
    my $changes_only=$args{'changes_only'} || "";

	my @smtp_server_values = get_smtp_server_by_name("$server","$gip_job_status_id"); 

	my $user = $smtp_server_values[0]->[2] || "";
	my $pass = $smtp_server_values[0]->[3] || "";
	my $security = $smtp_server_values[0]->[5] || "";
	my $port = $smtp_server_values[0]->[6] || "";
	my $timeout = $smtp_server_values[0]->[7] || "";

	my $error = "";

    my @months = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );
	my @days = qw(Sun Mon Tue Wed Thu Fri Sat Sun);
    my $zone_num = strftime("%z", localtime());
    my $zone_string = strftime("%Z", localtime());

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
	$year = $year + 1900;
   	my $mail_date = "$days[$wday], $mday $months[$mon] $year $hour:$min:$sec $zone_num ($zone_string)";

	my @log;
	if ( $log =~ /,/ ) {
		@log = split(",", $log);
	} else {
		push @log, $log if $log;
	}

	if ( $log ) {
        my $script_name_message = "";
        my $execution_time_message = "";
		foreach my $log_mail ( @log ) {
			open (LOG_MAIL,"<$log_mail") or $error = "can not open log file: $!\n";
			while (<LOG_MAIL>) {
                if ( $changes_only ) {
                    if ( $_ =~ /###/ ) {
                        $script_name_message = $_ if $log !~ /discover_network/;
                        next;
                    }
                    if ( $_ =~ /Execution time/i ) {
                        $execution_time_message = $_;
                        next;
                    }
                    if ( $_ !~ /added|updated|deleted|ERROR|EXECUTING|discovery|Execution time/i ) {
                        next;
                    }
                    if ( $_ =~ /Network discovery -|VLAN discovery -|Host discovery DNS -|Host discovery SNMP -/i ) {
                        $_ .= "\n";
                    }
                }
                $message .= $_;
			}
			close LOG_MAIL;
		}
        $message = $script_name_message . "\n" . $message if $script_name_message;
        if ( $changes_only && $message !~ /added|updated|deleted/i ) {
            $message .= "\nNo changes\n" if $log !~ /discover_network/;
        }
        $message .= "\n" . $execution_time_message if $execution_time_message;
	}

    $message = "\n$message";

	open (LOG_MAIL,">>$log") or $error = "can not open log file: $!\n";
	*STDERR = *LOG_MAIL;

	foreach my $to ( @$mail_to ) {

        print "SENDING MAIL: $to\n";

		my $mailer = new Net::SMTP(  
			$server,  
			Hello	=>      'localhost',
			Port	=>      $port,  
			Timeout	=>      $timeout,
			Debug	=>      $debug,
	#		SSL		=>		1,
		);

		if ( $security eq "starttls" ) {
			$mailer->starttls();
        }
		if ( $user ) {
			$mailer->auth($user,$pass) or $error = $mailer->message();
		}
		$mailer->mail($mail_from) or $error .= $mailer->message();  
		$mailer->to($to) or $error .= $mailer->message();  
		$mailer->data() or $error .= $mailer->message();  
		$mailer->datasend('Date: ' . $mail_date) or $error .= $mailer->message();
		$mailer->datasend("\n") or $error .= $mailer->message();
		$mailer->datasend('Subject: ' . $subject) or $error .= $mailer->message();
		$mailer->datasend("\n") or $error .= $mailer->message();
		$mailer->datasend('From: ' . $mail_from) or $error .= $mailer->message();
		$mailer->datasend("\n") or $error .= $mailer->message();
		$mailer->datasend('To: ' . $to) or $error .= $mailer->message();
		$mailer->datasend("\n") or $error .= $mailer->message();
		$mailer->datasend($message) or $error .= $mailer->message();
		$mailer->dataend or $error .= $mailer->message();  
		$mailer->quit or $error .= $mailer->message(); 

		sleep 1;
	}

	close LOG_MAIL;
	*STDERR = *STDOUT;

	return $error;
}

sub get_smtp_server_by_name {
    my ( $name, $gip_job_status_id ) = @_;

    $gip_job_status_id = "" if ! $gip_job_status_id;

    my @values;
    my $ip_ref;
	my $dbh = ::mysql_connection() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
    my $qname = $dbh->quote( $name );
    my $sth = $dbh->prepare("SELECT id, name, username, password, default_from, security, port, timeout, comment, client_id FROM smtp_server WHERE name=$qname") or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
    $sth->execute() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
    while ( $ip_ref = $sth->fetchrow_arrayref ) {
        push @values, [ @$ip_ref ];
    }
    $sth->finish();
    $dbh->disconnect;

    return @values;
}

sub create_log_file {
	my ( $client, $logfile_name, $base_dir, $log_dir, $script ) = @_;
	if ( ! $log_dir ) {
		$log_dir = $base_dir . '/var/log';
		if ( ! -d $log_dir ) {
			$log_dir = "/usr/share/gestioip/var/log";
		}
	}
	if ( ! -d $log_dir ) {
		::exit_error("Log directory not found $log_dir", "", "");
	}
	if ( ! -w $log_dir ) {
		::exit_error("Log directory not writable $log_dir", "", "");
	}

    my ($s, $mm, $h, $d, $m, $y) = (localtime) [0,1,2,3,4,5];
	$m++;
	$y+=1900;
	if ( $d =~ /^\d$/ ) { $d = "0$d"; }
	if ( $s =~ /^\d$/ ) { $s = "0$s"; }
	if ( $m =~ /^\d$/ ) { $m = "0$m"; }
	if ( $mm =~ /^\d$/ ) { $mm = "0$mm"; }

	my $log_date="$y$m$d$h$mm$s";
	my $datetime = "$y-$m-$d $h:$mm:$s";

	if ( $logfile_name ) {
		$logfile_name =~ s/\s/_/g;
		$logfile_name =~ s/\//_/g;
		$logfile_name =~ s/_+/_/g;
	} else {
		$logfile_name = $log_date . "_" . $client . "_" . $script . ".log";
	}

	my $log=$log_dir . "/" . $logfile_name;

	return ($log, $datetime);
}


sub get_tag_hash {
	my ( $client_id, $key, $gip_job_status_id ) = @_;
	my %values;
	my $ip_ref;
	$key = "id" if ! $key;
	my $dbh = ::mysql_connection() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
	my $qclient_id = $dbh->quote( $client_id );
	my $sth = $dbh->prepare("SELECT id, name, description, color, client_id FROM tag WHERE client_id = $qclient_id ORDER BY name"
		) or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
	$sth->execute() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
	while ( $ip_ref = $sth->fetchrow_hashref ) {
		my $id = $ip_ref->{id};
		my $name = $ip_ref->{name};
		my $description = $ip_ref->{description};
		my $color = $ip_ref->{color};
		my $client_id = $ip_ref->{client_id};
		if ( $key eq "id" ) {
			push @{$values{$id}},"$name","$description","$color","$client_id";
		} elsif ( $key eq "name" ) {
			push @{$values{$name}},"$id","$description","$color","$client_id";
		}
	}
	$sth->finish();
	$dbh->disconnect;

	return %values;
}


sub insert_tag_for_object {
	my ( $tag_id, $object_id, $object, $gip_job_status_id ) = @_;

	my ($table, $col_name);
	if ( $object eq "network" ) {
		$table = "tag_entries_network";
		$col_name = "net_id";
	} elsif ( $object eq "host" ) {
		$table = "tag_entries_host";
		$col_name = "host_id";
	}

	my @values;
	my $ip_ref;
	my $dbh = ::mysql_connection() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
	my $qtag_id = $dbh->quote( $tag_id );
	my $qobject_id = $dbh->quote( $object_id );
	my $qcol_name = $dbh->quote( $col_name );
	my $sth = $dbh->prepare("INSERT INTO $table (tag_id, $col_name) VALUES ($qtag_id, $qobject_id)") or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
	$sth->execute() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
	$sth->finish();
	$dbh->disconnect;
}


sub get_scheduled_job_hash {
    my ( $gip_job_id, $key, $gip_job_status_id ) = @_;

	$gip_job_status_id = "" if ! $gip_job_status_id;

    my %values;
    my $ip_ref;
    $key = "id" if ! $key;
	my $dbh = ::mysql_connection() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
    my $qgip_job_id = $dbh->quote( $gip_job_id );
    my $sth = $dbh->prepare("SELECT id, name, type, start_date, end_date, run_once, status, comment, arguments, cron_time, next_run, repeat_interval, client_id FROM scheduled_jobs WHERE id=$qgip_job_id ORDER BY id"
        ) or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
    $sth->execute() or exit_error("Cannot execute statement: " . $DBI::errstr, "$gip_job_status_id", 4);
    while ( $ip_ref = $sth->fetchrow_hashref ) {
        my $id = $ip_ref->{id};
        my $name = $ip_ref->{name};
        my $type = $ip_ref->{type};
        my $start_date = $ip_ref->{start_date};
        my $end_date = $ip_ref->{end_date};
        my $run_once = $ip_ref->{run_once};
        my $status = $ip_ref->{status};
        my $comment = $ip_ref->{comment};
        my $arguments = $ip_ref->{arguments};
        my $cron_time = $ip_ref->{cron_time};
        my $next_run = $ip_ref->{next_run};
        my $repeat_interval = $ip_ref->{repeat_interval};
        my $client_id = $ip_ref->{client_id};
        if ( $key eq "id" ) {
            push @{$values{$id}},"$name", "$start_date","$end_date", "$run_once", "$status", "$comment", "$arguments", "$cron_time", "$next_run", "$repeat_interval", "$type", "$client_id", "$end_date";
        } elsif ( $key eq "name" ) {
            push @{$values{$name}},"$id", "$start_date","$end_date", "$run_once", "$status", "$comment", "$arguments", "$cron_time", "$next_run", "$repeat_interval", "$type", "$client_id", "$end_date";
        }
    }
    $sth->finish();
    $dbh->disconnect;

    return \%values;
}

sub check_start_date {
    my ( $gip_job_id, $gip_job_status_id ) = @_;

	my $job_hash = get_scheduled_job_hash("$gip_job_id", "id", $gip_job_status_id);

	my $start_time = $job_hash->{$gip_job_id}[1] || "";

	if ( $start_time !~ /^(\d+)\/(\d+)\/(\d+) (\d+):(\d+)/ ) {
		print "start_time: WRONG FORMAT\n";
		exit 1;
	}

    $start_time =~ /^(\d+)\/(\d+)\/(\d+) (\d+):(\d+)/;
    my $st_day = $1;
    my $st_month = $2;
    my $st_year = $3;
    my $st_hour = $4;
    my $st_minute = $5;
    my $st_sec = "00";
    my $st_epoch = timelocal($st_sec,$st_minute,$st_hour,$st_day,$st_month-1,$st_year);

    my $now_epoch = time();
    my $now_time = strftime "%d/%m/%Y %H:%M", localtime($now_epoch);

	if ( $now_epoch < $st_epoch ) {
		return "TOO_EARLY";
	} else {
		return;
	}

}

sub check_end_date {
    my ( $gip_job_id, $gip_job_status_id ) = @_;

	my $job_hash = get_scheduled_job_hash("$gip_job_id", "id", $gip_job_status_id);

	my $end_time = $job_hash->{$gip_job_id}[2] || "";

    return if ! $end_time;

	if ( $end_time !~ /^(\d+)\/(\d+)\/(\d+) (\d+):(\d+)/ ) {
		print "end_time: WRONG FORMAT\n";
		exit 1;
	}

    $end_time =~ /^(\d+)\/(\d+)\/(\d+) (\d+):(\d+)/;
    my $et_day = $1;
    my $et_month = $2;
    my $et_year = $3;
    my $et_hour = $4;
    my $et_minute = $5;
    my $et_sec = "00";
    my $et_epoch = timelocal($et_sec,$et_minute,$et_hour,$et_day,$et_month-1,$et_year);

    my $now_epoch = time();
    my $now_time = strftime "%d/%m/%Y %H:%M", localtime($now_epoch);

	if ( $now_epoch > $et_epoch ) {
		return "TOO_LATE";
	} else {
		return;
	}
}

sub check_disabled {
    my ( $gip_job_id ) = @_;

	my $job_hash = get_scheduled_job_hash("$gip_job_id", "id", "");

	my $status = $job_hash->{$gip_job_id}[4] || "";

	return $status;

}

sub get_job_name {
    my ( $gip_job_id ) = @_;

	my $job_hash = get_scheduled_job_hash("$gip_job_id", "id", "");

	my $name = $job_hash->{$gip_job_id}[0] || "";

	return $name;
}

1;
